<div class="footer">
	<div class="footer_social">
		<p>A Subsidiary of Variance Technologies Solutions Pvt Ltd.</p>
	</div>
	<p>Copyright &copy 2014 By Varinformatics All rights reserved</p>
</div>
</body>
</html>