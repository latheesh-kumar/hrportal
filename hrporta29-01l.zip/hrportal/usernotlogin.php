<?php
if($_SESSION['isLogged']==false) {
header("location:index.php"); 
die(); 
}
?>

